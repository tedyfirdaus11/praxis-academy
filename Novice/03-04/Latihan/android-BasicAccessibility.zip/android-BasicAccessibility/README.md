
Android BasicAccessibility Sample
=================================


This sample has been deprecated/archived meaning it's read-only and it's no longer actively maintained (more details on archiving can be found [here][1]).

For more information on accessibility, check out our [docs and samples][2]. Thank you!

[1]: https://help.github.com/en/articles/about-archiving-repositories
[2]: https://developer.android.com/guide/topics/ui/accessibility
